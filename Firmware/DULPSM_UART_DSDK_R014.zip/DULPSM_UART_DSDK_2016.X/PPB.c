#include <xc.h>
#include <math.h>
#include "LMP91000.h"

double PPB_Calculation(unsigned int ADC, unsigned int ADC_Zero, int nA_per_PPM_x100, double T_float, unsigned long int Part_Number)
{
    double Tkz = 25;
    double Tks = 25;  
    double nA;
    double Cx;
    unsigned long int Rgain;
    double Zc;
    double Zcf;
    double Zcf_low;
    double Zcf_high;   
    double Sc;
    double Scf;
    double Scf_low;
    double Scf_high; 
    unsigned int LMP91000_B01;
    unsigned int LMP91000_B10;
    unsigned int LMP91000_B11;
    unsigned int LMP91000_B12;
    unsigned int TIA_GAIN;

    LMP91000_B10 = LMP91000_Read(0x10);
    LMP91000_B11 = LMP91000_Read(0x11);
    LMP91000_B12 = LMP91000_Read(0x12);
    
    TIA_GAIN = LMP91000_B10 & 0b00011111;
    TIA_GAIN = TIA_GAIN >> 2;
    
    if(TIA_GAIN == 0)
    {
        Rgain = 499000;
    }
    else if(TIA_GAIN == 1)
    {
        Rgain = 2735;
    }
    else if(TIA_GAIN == 2)
    {
        Rgain = 3476;
    }
    else if(TIA_GAIN == 3)
    {
        Rgain = 6903;
    }
    else if(TIA_GAIN == 4)
    {
        Rgain = 13618;
    }
    else if(TIA_GAIN == 5)
    {
        Rgain = 32706;
    }
    else if(TIA_GAIN == 6)
    {
        Rgain = 96737;
    }
    else if(TIA_GAIN == 7)
    {
        Rgain = 205713;
    }
    else
    {
        Rgain = 499000;
    }

    if(Part_Number == 110102)
    {
        Zcf_low = 0;
        Zcf_high = 2.375;
        Scf_low = 0.6;
        Scf_high = 0.4;
    }
    else if(Part_Number == 110202)
    {
        Zcf_low = 1.7;
        Zcf_high = 22.5;
        Scf_low = 1.2;
        Scf_high = 0;
    }
    else if(Part_Number == 110303)
    {
        Zcf_low = 0;
        Zcf_high = 0;
        Scf_low = 0.3;
        Scf_high = 0;
    }
    else if(Part_Number == 110601)
    {
        Zcf_low = 0;
        Zcf_high = 15;
        Scf_low = 1.2;
        Scf_high = 0.5;
    }
    else if(Part_Number == 110501)
    {
        Zcf_low = 0;
        Zcf_high = -1.6;
        Scf_low = 0;
        Scf_high = 0.4;
    }
    else if(Part_Number == 110401)
    {
        Zcf_low = 0;
        Zcf_high = 0;
        Scf_low = 0;
        Scf_high = 0.5;
    }
    else if(Part_Number == 110801)
    {
        Zcf_low = 0;
        Zcf_high = 0;
        Scf_low = 0;
        Scf_high = 0;
    }
    else if(Part_Number == 110901)
    {
        Zcf_low = 0;
        Zcf_high = 0;
        Scf_low = 0;
        Scf_high = 0;
    }
    else if(Part_Number == 999036)
    {
        Zcf_low = 0;
        Zcf_high = 0;
        Scf_low = 0;
        Scf_high = 0;
    }
    else;
    
    if(T_float < Tkz)
    {
        Zcf = Zcf_low;
    }
    else
    {
        Zcf = Zcf_high;
    }
    
    if(T_float < Tks)
    {
        Scf = Scf_low;
    }
    else
    {
        Scf = Scf_high; 
    }
       
    nA = ((double)ADC - (double)ADC_Zero) / 65535 * 2.048 / (double)Rgain * 1E9;    //formula for 2.048V reference
//    nA = ((double)ADC - (double)ADC_Zero) / 65535 * 2.5 / (double)Rgain * 1E9;    //formula for 2.5V reference
    Zc = nA - (Zcf * (T_float - Tkz));
    Sc = 1 - (Scf / 100 * (T_float - Tks));
    Cx = Zc * Sc / (double)nA_per_PPM_x100 * 1E5;   //Concentration with temperature compensation   
//    Cx = nA / (double)nA_per_PPM_x100 * 1E5; //Concentration without temperature compensation

    return Cx;
}
