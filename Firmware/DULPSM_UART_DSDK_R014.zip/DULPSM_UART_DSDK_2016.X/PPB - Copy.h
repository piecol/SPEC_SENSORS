#ifndef PPB_H
#define	PPB_H

#include <xc.h> 

//double PPB_calculation(unsigned int User_ADC_Zero, unsigned int Default_ADC_Zero, double T_float, unsigned int Default_pA_per_PPM, 
//                       double Default_1000x_A, double Default_1000x_B, double Default_100000x_m, 
//                       double Default_100x_C0, double Default_10000x_C1, double Default_1000000x_C2);
double PPB_Calculation(unsigned int ADC, unsigned int ADC_Zero, unsigned int pA_per_PPM, double T_float, unsigned long int Part_Number);

#endif

