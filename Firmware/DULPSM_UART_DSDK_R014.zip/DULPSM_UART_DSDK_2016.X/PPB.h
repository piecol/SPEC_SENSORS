#ifndef PPB_H
#define	PPB_H

#include <xc.h> 

double PPB_Calculation(unsigned int ADC, unsigned int ADC_Zero, unsigned int pA_per_PPM, double T_float, unsigned long int Part_Number);

#endif

