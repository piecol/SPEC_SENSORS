#ifndef RTCC_H
#define	RTCC_H

#include <xc.h> 

void RTCC_init(void);
void RTCC_start(void);

#endif

