#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
//#include <i2c.h>
#include <math.h>
#include "i2c2.h"
#include "delay.h"
#include "adc.h"
#include "LMP91000.h"
#include "UART2.h"
#include "EEPROM.h"
#include "RTCC.h"
#include "Si7021.h"
#include "PPB.h"

// FBS
#pragma config BWRP = OFF               // Boot Segment Write Protect (Disabled)
#pragma config BSS = OFF                // Boot segment Protect (No boot program flash segment)
//#pragma config BSS = HI2K               // Boot segment Protect (High Security Boot Protect 000200h - 0015FEh)

// FGS
#pragma config GWRP = OFF               // General Segment Write Protect (General segment may be written)
//#pragma config GCP = OFF                // General Segment Code Protect (No Protection)
#pragma config GCP = ON                 // General Segment Code Protect (Standard security enabled)

// FOSCSEL
#pragma config FNOSC = FRC              // Oscillator Select (Fast RC Oscillator (FRC))
//#pragma config FNOSC = FRCDIV           // Oscillator Select (8MHz FRC oscillator With Postscaler (FRCDIV))
//#pragma config FNOSC = FRCPLL           // Oscillator Select (Fast RC Oscillator with Postscaler and PLL Module (FRCDIV+PLL))
#pragma config SOSCSRC = ANA            // SOSC Source Type (Analog Mode for use with crystal)
#pragma config LPRCSEL = HP             // LPRC Oscillator Power and Accuracy (High Power, High Accuracy Mode)
#pragma config IESO = OFF               // Internal External Switch Over bit (Internal External Switchover mode disabled (Two-speed Start-up disabled))

// FOSC
#pragma config POSCMOD = NONE           // Primary Oscillator Configuration bits (Primary oscillator disabled)
#pragma config OSCIOFNC = IO            // CLKO Enable Configuration bit (Port I/O enabled (CLKO disabled))
#pragma config POSCFREQ = HS            // Primary Oscillator Frequency Range Configuration bits (Primary oscillator/external clock input frequency greater than 8MHz)
#pragma config SOSCSEL = SOSCHP         // SOSC Power Selection Configuration bits (Secondary Oscillator configured for high-power operation)
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor Selection (Both Clock Switching and Fail-safe Clock Monitor are disabled)
//#pragma config FCKSM = CSECMD           // Clock Switching and Monitor Selection (Clock Switching is enabled, Fail-safe Clock Monitor is disabled)

// FWDT
//#pragma config WDTPS = PS32768          // Watchdog Timer Postscale Select bits (1:32768)
//#pragma config WDTPS = PS16384          // Watchdog Timer Postscale Select bits (1:16384)
#pragma config WDTPS = PS8192           // Watchdog Timer Postscale Select bits (1:8192)
//#pragma config WDTPS = PS4096           // Watchdog Timer Postscale Select bits (1:4096)
//#pragma config WDTPS = PS2048           // Watchdog Timer Postscale Select bits (1:2048)
//#pragma config WDTPS = PS1024           // Watchdog Timer Postscale Select bits (1:1024)
//#pragma config WDTPS = PS256            // Watchdog Timer Postscale Select bits (1:256)
//#pragma config FWPSA = PR128            // WDT Prescaler bit (WDT prescaler ratio of 1:128)
#pragma config FWPSA = PR32             // WDT Prescaler bit (WDT prescaler ratio of 1:32)
//#pragma config FWDTEN = OFF             // Watchdog Timer Enable bits (WDT disabled in hardware; SWDTEN bit disabled)
#pragma config FWDTEN = SWON            // Watchdog Timer Enable bits (WDT controlled with the SWDTEN bit setting)
#pragma config WINDIS = OFF             // Windowed Watchdog Timer Disable bit (Standard WDT selected(windowed WDT disabled))

// FPOR
#pragma config BOREN = BOR3             // Brown-out Reset Enable bits (Brown-out Reset enabled in hardware, SBOREN bit disabled)
#pragma config PWRTEN = OFF             // Power-up Timer Enable bit (PWRT disabled)
#pragma config I2C1SEL = PRI            // Alternate I2C1 Pin Mapping bit (Use Default SCL1/SDA1 Pins For I2C1)
#pragma config BORV = V18               // Brown-out Reset Voltage bits (Brown-out Reset set to lowest voltage (1.8V))
#pragma config MCLRE = ON               // MCLR Pin Enable bit (RA5 input pin disabled, MCLR pin enabled)

// FICD
#pragma config ICS = PGx3               // ICD Pin Placement Select bits (EMUC/EMUD share PGC3/PGD3)

//#define Default_1000x_A_Basic 4190.94420905486;
//#define Default_1000x_B_Basic -20126.6935226212;
//#define Default_100000x_m_Basic 7927.64955985264;
//#define Default_1000000x_C2_Basic -6066.52871527976;
//#define Default_10000x_C1_Basic 7748.74390686915;
//#define Default_100x_C0_Basic 8690.97602867663;
//
//#define Default_1000x_A_Standard 4190.94420905486;
//#define Default_1000x_B_Standard -20126.6935226212;
//#define Default_100000x_m_Standard 7927.64955985264;
//#define Default_1000000x_C2_Standard -6066.52871527976;
//#define Default_10000x_C1_Standard 7748.74390686915;
//#define Default_100x_C0_Standard 8690.97602867663;
//
//#define Default_1000000x_C2_Plus -6066.52871527976;
//#define Default_10000x_C1_Plus 7748.74390686915;
//#define Default_100x_C0_Plus 8690.97602867663;

char Buffer[100];

void Port_init(void)
{
    ANSA = 0b0000000000010000;
    ANSB = 0x0000;

    TRISAbits.TRISA0 = 1;
    TRISAbits.TRISA1 = 1;
    TRISAbits.TRISA2 = 1;
    TRISAbits.TRISA3 = 1;
    TRISAbits.TRISA4 = 1;
//    TRISAbits.TRISA5 = 1;
    TRISAbits.TRISA6 = 1;
    TRISAbits.TRISA7 = 1;
    TRISBbits.TRISB0 = 0;
    TRISBbits.TRISB1 = 1;
//    TRISBbits.TRISB2 = 1;
//    TRISBbits.TRISB3 = 1;
    TRISBbits.TRISB4 = 1;
//    TRISBbits.TRISB5 = 1;
//    TRISBbits.TRISB6 = 1;
    TRISBbits.TRISB7 = 1;
//    TRISBbits.TRISB8 = 1;
//    TRISBbits.TRISB9 = 1;
    TRISBbits.TRISB10 = 1;
    TRISBbits.TRISB11 = 1;
    TRISBbits.TRISB12 = 1;
    TRISBbits.TRISB13 = 1;
    TRISBbits.TRISB14 = 1;
    TRISBbits.TRISB15 = 0;
}

void Oscillator_init(void)
{
//    CLKDIVbits.RCDIV = 0;
    RCONbits.SWDTEN = 1;
}

void Unlock(unsigned int Security_Code)
{
    long unsigned int i;
    char Buffer[100];
    char user_input;

    UART2_xmits("Enter Unlock Code: ");
    
    i = 0;
    while(i < 100)
    {
        Buffer[i] = '\0';
        i++;
    }

//    ClrWdt();
    i = 0;
    while(1)
    {
        if(IFS1bits.U2RXIF)
        {
            IFS1bits.U2RXIF = 0;
            user_input = U2RXREG;
//            UART2_xmitc(user_input);
            if(user_input == '\r')
            {
                break;
            }
            else;
            Buffer[i] = user_input;
            i++;
        }
//        ClrWdt();
    }

    if(Security_Code != (atoi(Buffer)))
    {
        UART2_xmits("\r\n");
        while(1);
    }
    else
    {
//        UART2_xmits_NewLine("Successfully unlocked                     ");
    }
}

void UART_Entry(void)
{
    unsigned int i;
    char user_input;

    
    ClrWdt();
    i = 0;
    while(i < 100)
    {
        Buffer[i] = '\0';
        i++;
    }

    i = 0;
    while(i < 100)
    {    
//                                                                                U2STAbits.OERR = 0;
        if(IFS1bits.U2RXIF)
        {            
            IFS1bits.U2RXIF = 0;
//                                                                                U2STAbits.OERR = 0;
            user_input = U2RXREG;
            UART2_xmitc(user_input);
            if(user_input == '\r')
            {
                break;
            }
            else;

            Buffer[i] = user_input;
            i++;
        }
//        ClrWdt();
    }
}

/**************************************************************************Main**********************************************************************/   
int main(void)
{
    unsigned long int i;
    unsigned long int j;
    unsigned long int k;
    char Operation_Mode;
    char Board_Name;
    char Board_Name_[12];    
    char user_input;
    unsigned int T;
    unsigned int RH;
    double T_float;
    double User_T_Zero_float;
    double RH_float;
//    char verbose;
    int Default_1000x_Temperature_Offset;
    unsigned long int counter = 0;
    
    unsigned int LMP91000_B11;

    unsigned int Security_Code = 58008;

    unsigned int Default_ADC_OC;

    unsigned int Default_ADC_Zero;
    unsigned int Default_T_Zero;
    unsigned int Default_RH_Zero;

    unsigned int Default_ADC_Span;

    unsigned int User_ADC_Zero;
    unsigned int User_T_Zero;
    unsigned int User_RH_Zero;

    unsigned int User_ADC_Span;
    unsigned int ADC;

    double cx;
    double PPB_CO;
    double PPB_old;
    
    unsigned int Default_pA_per_PPM_Basic;
    unsigned int Default_pA_per_PPM_Standard;
    unsigned int Default_pA_per_PPM_Plus;
    double Zero_compensation;
    double Span_compensation;
    
    double Default_1000x_A_Basic = 4190.94420905486;
    double Default_1000x_B_Basic = -20126.6935226212;
    double Default_100000x_m_Basic = 7927.64955985264;
    double Default_1000000x_C2_Basic = -6066.52871527976;
    double Default_10000x_C1_Basic = 7748.74390686915;
    double Default_100x_C0_Basic = 8690.97602867663;
    
    double Default_1000x_A_Standard = 4190.94420905486;
    double Default_1000x_B_Standard = -20126.6935226212;
    double Default_100000x_m_Standard = 7927.64955985264;
    double Default_1000000x_C2_Standard = -6066.52871527976;
    double Default_10000x_C1_Standard = 7748.74390686915;
    double Default_100x_C0_Standard = 8690.97602867663;
  
    int Default_1000x_A_Plus;
    int Default_1000x_B_Plus;
    int Default_100000x_m_Plus;
    double Default_1000000x_C2_Plus = -6066.52871527976;
    double Default_10000x_C1_Plus = 7748.74390686915;
    double Default_100x_C0_Plus = 8690.97602867663;
    
    unsigned int Readout_delay = 0;
    unsigned int YRTEN;
    unsigned int YRONE;
    unsigned int MTHTEN;
    unsigned int MTHONE;
    unsigned int DAYTEN;
    unsigned int DAYONE;
    unsigned int HRTEN;
    unsigned int HRONE;
    unsigned int MINTEN;
    unsigned int MINONE;
    unsigned int SECTEN;
    unsigned int SECONE;

    I2C2_init();
    Port_init();
    UART2_init();
    ADC_init();
    Oscillator_init();
/**************************************************************Power-On Startup Sequence**************************************************************/
    if(RCONbits.POR | RCONbits.BOR)
    {
        RCONbits.POR = 0;
        RCONbits.BOR = 0;
        
        RTCC_init();

//        Default_1000x_A_Basic = readNVM(2);
//        Default_1000x_B_Basic = readNVM(4);
//        Default_100000x_m_Basic = readNVM(6);
        Default_ADC_OC = readNVM(12);
//        Default_1000000x_C2_Basic = readNVM(14);
//        Default_10000x_C1_Basic = readNVM(16);
//        Default_100x_C0_Basic = readNVM(18);  
        Default_1000x_Temperature_Offset = readNVM(20);
        Default_ADC_Zero = readNVM(30);
        Default_T_Zero = readNVM(32);
        Default_RH_Zero = readNVM(34);
        Default_ADC_Span = readNVM(40);
        LMP91000_B11 = readNVM(54);
        Default_pA_per_PPM_Basic = readNVM(70);
        Default_pA_per_PPM_Standard = readNVM(72);
        Default_pA_per_PPM_Plus = readNVM(74);
        Operation_Mode = readNVM(80);
        Board_Name = readNVM(90);
        Board_Name_[0] = readNVM(100);
        Board_Name_[1] = readNVM(102);
        Board_Name_[2] = readNVM(104);
        Board_Name_[3] = readNVM(106);
        Board_Name_[4] = readNVM(108);
        Board_Name_[5] = readNVM(110);
        Board_Name_[6] = readNVM(112);
        Board_Name_[7] = readNVM(114);
        Board_Name_[8] = readNVM(116);
        Board_Name_[9] = readNVM(118);
        Board_Name_[10] = readNVM(120);
        Board_Name_[11] = readNVM(122);        
        User_ADC_Zero = readNVM(130);
        User_T_Zero = readNVM(132);
        User_RH_Zero = readNVM(134);

        Default_1000x_A_Plus = readNVM(202);
        Default_1000x_B_Plus = readNVM(204);
        Default_100000x_m_Plus = readNVM(206);
//        Default_1000000x_C2_Plus = readNVM(214);
//        Default_10000x_C1_Plus = readNVM(216);
//        Default_100x_C0_Plus = readNVM(218);
        
        RTCC_start();

        LMP91000_Unlock();
        LMP91000_0x10(0b00000011);
        LMP91000_0x11(LMP91000_B11);
        LMP91000_0x12();
    }
    else;

    if(RCONbits.WDTO)
    {
        U2MODEbits.UARTEN = 0;
        U2MODEbits.USIDL = 0;
        U2MODEbits.WAKE = 1;

        //  U1BRG = (Fcy/(32*BaudRate)) - 1  or  U1BRG = (Fcy/(8*BaudRate)) - 1
        U2BRG = 25;	// 7.37Mhz osc, 9600 Baud BRGH = 0 

        IEC1bits.U2RXIE = 1;

        U2MODEbits.UARTEN = 1;	// And turn the peripheral on
        U2STAbits.UTXEN = 1;

        RCONbits.WDTO = 0;
        RCONbits.SWDTEN = 0;
        delay(1000);
        Sleep();
        while(1);
    }
    else;
 
/************************************************************************Run Mode********************************************************************/    
    while(1)
    {      
        if(counter > 0)
        {
            UART2_xmits("Enter output interval(5, 10, 30, 60s): ");
            UART_Entry();

            Readout_delay = atoi(Buffer);
            UART2_xmits("\r\n");
        }

        do
        {          
            ADC = ADC_Read(16);

            if(Operation_Mode == '0')  
            {   
                UART2_xmits(Board_Name_);  
                UART2_xmits(", ");
            }
            else if((Operation_Mode == '1') | (Operation_Mode == '2') | (Operation_Mode == '3'))   
            {   
                UART2_xmits(Board_Name_);  
            }
            else;

            if((Operation_Mode != '1') & (Operation_Mode != '2') & (Operation_Mode != '3'))   
            {
                utoa(Buffer, ADC, 10);
                delay(1000);  
                UART2_xmits(Buffer);
            }
            else;

            T = Si7021_Read_T();
            T_float = Si7021_Calculate_T(T);
            
            User_T_Zero_float = Si7021_Calculate_T(User_T_Zero);

            if((Operation_Mode == '0') | (Operation_Mode == '1'))   
            {  
                if((Default_T_Zero != User_T_Zero) | (Default_ADC_Zero != User_ADC_Zero))
                {
//                    cx = ((double)User_ADC_Zero - (double)Default_ADC_Zero);
//                    cx = cx * 0.076295109483;
//                    Zero_compensation = (double)Default_100000x_m_Basic / 100000 * User_T_Zero_float;
//                    Zero_compensation = exp(Zero_compensation);
//                    Zero_compensation = Zero_compensation * (double)Default_1000x_A_Basic / 1000;
//                    Zero_compensation = Zero_compensation + (double)Default_1000x_B_Basic / 1000;
//                    Zero_compensation = cx - Zero_compensation;
//                    Zero_compensation = 1000 * Zero_compensation / (double)Default_pA_per_PPM_Basic;
//                    Span_compensation = Default_100x_C0_Basic / 100;
//                    Span_compensation = Span_compensation + ((double)Default_10000x_C1_Basic / 10000 * User_T_Zero_float);
//                    Span_compensation = Span_compensation + ((double)Default_1000000x_C2_Basic / 1000000 * User_T_Zero_float * User_T_Zero_float);
//                    Span_compensation = Span_compensation / 100;
//                    PPB_old = 1000 * Zero_compensation / Span_compensation;
                    
                    PPB_old = PPB_calculation(User_ADC_Zero, Default_ADC_Zero, User_T_Zero_float, Default_pA_per_PPM_Basic, 
                                                            Default_1000x_A_Basic, Default_1000x_B_Basic, Default_100000x_m_Basic, 
                                                            Default_100x_C0_Basic, Default_10000x_C1_Basic, Default_1000000x_C2_Basic);
                }
                else
                {
                    PPB_old = 0;
                }
                
//                cx = ((double)ADC - (double)Default_ADC_Zero);
//                cx = cx * 0.076295109483;
//                Zero_compensation = (double)Default_100000x_m_Basic / 100000 * T_float;
//                Zero_compensation = exp(Zero_compensation);
//                Zero_compensation = Zero_compensation * (double)Default_1000x_A_Basic / 1000;
//                Zero_compensation = Zero_compensation + (double)Default_1000x_B_Basic / 1000;
//                Zero_compensation = cx - Zero_compensation;
//                Zero_compensation = 1000 * Zero_compensation / (double)Default_pA_per_PPM_Basic;
//                Span_compensation = Default_100x_C0_Basic / 100;
//                Span_compensation = Span_compensation + ((double)Default_10000x_C1_Basic / 10000 * T_float);
//                Span_compensation = Span_compensation + ((double)Default_1000000x_C2_Basic / 1000000 * T_float * T_float);
//                Span_compensation = Span_compensation / 100;
//                PPB_CO = 1000 * Zero_compensation / Span_compensation - PPB_old;
                
                PPB_CO = PPB_calculation(ADC, Default_ADC_Zero, T_float, Default_pA_per_PPM_Basic, 
                                             Default_1000x_A_Basic, Default_1000x_B_Basic, Default_100000x_m_Basic, 
                                             Default_100x_C0_Basic, Default_10000x_C1_Basic, Default_1000000x_C2_Basic) - PPB_old;

                if((PPB_CO < 0) & (Operation_Mode == '1'))
                {
                    PPB_CO = 0;
                }
                else;

                ltoa(Buffer, (long int)PPB_CO, 10);
                delay(1000);
                UART2_xmits(", ");
                UART2_xmits(Buffer);
            }
            else;                                                                    
            
            if((Operation_Mode == '0') | (Operation_Mode == '2'))   
            {   
                if((Default_T_Zero != User_T_Zero) | (Default_ADC_Zero != User_ADC_Zero))
                {
//                    cx = ((double)User_ADC_Zero - (double)Default_ADC_Zero);
//                    cx = cx * 0.076295109483;
//                    Zero_compensation = (double)Default_100000x_m_Standard / 100000 * User_T_Zero_float;
//                    Zero_compensation = exp(Zero_compensation);
//                    Zero_compensation = Zero_compensation * (double)Default_1000x_A_Standard / 1000;
//                    Zero_compensation = Zero_compensation + (double)Default_1000x_B_Standard / 1000;
//                    Zero_compensation = cx - Zero_compensation;
//                    Zero_compensation = 1000 * Zero_compensation / (double)Default_pA_per_PPM_Standard;
//                    Span_compensation = Default_100x_C0_Standard / 100;
//                    Span_compensation = Span_compensation + ((double)Default_10000x_C1_Standard / 10000 * User_T_Zero_float);
//                    Span_compensation = Span_compensation + ((double)Default_1000000x_C2_Standard / 1000000 * User_T_Zero_float * User_T_Zero_float);
//                    Span_compensation = Span_compensation / 100;
//                    PPB_old = 1000 * Zero_compensation / Span_compensation;
                    
                    PPB_old = PPB_calculation(User_ADC_Zero, Default_ADC_Zero, User_T_Zero_float, Default_pA_per_PPM_Standard, 
                                                             Default_1000x_A_Standard, Default_1000x_B_Standard, Default_100000x_m_Standard, 
                                                             Default_100x_C0_Standard, Default_10000x_C1_Standard, Default_1000000x_C2_Standard);
                }
                else
                {
                    PPB_old = 0;
                }
                
//                cx = ((double)ADC - (double)Default_ADC_Zero);
//                cx = cx * 0.076295109483;
//                Zero_compensation = (double)Default_100000x_m_Standard / 100000 * T_float;
//                Zero_compensation = exp(Zero_compensation);
//                Zero_compensation = Zero_compensation * (double)Default_1000x_A_Standard / 1000;
//                Zero_compensation = Zero_compensation + (double)Default_1000x_B_Standard / 1000;
//                Zero_compensation = cx - Zero_compensation;
//                Zero_compensation = 1000 * Zero_compensation / (double)Default_pA_per_PPM_Standard;
//                Span_compensation = Default_100x_C0_Standard / 100;
//                Span_compensation = Span_compensation + ((double)Default_10000x_C1_Standard / 10000 * T_float);
//                Span_compensation = Span_compensation + ((double)Default_1000000x_C2_Standard / 1000000 * T_float * T_float);
//                Span_compensation = Span_compensation / 100;
//                PPB_CO = 1000 * Zero_compensation / Span_compensation - PPB_old;
                
                PPB_CO = PPB_calculation(ADC, Default_ADC_Zero, T_float, Default_pA_per_PPM_Standard, 
                                              Default_1000x_A_Standard, Default_1000x_B_Standard, Default_100000x_m_Standard, 
                                              Default_100x_C0_Standard, Default_10000x_C1_Standard, Default_1000000x_C2_Standard) - PPB_old;
                
                if((PPB_CO < 0) & (Operation_Mode == '2'))
                {
                    PPB_CO = 0;
                }
                else;

                ltoa(Buffer, (long int)PPB_CO, 10);
                delay(1000);
                UART2_xmits(", ");
                UART2_xmits(Buffer);
            }
            else;
                                                                                
            if((Operation_Mode == '0') | (Operation_Mode == '3'))   
            {   
                T_float = T_float + ((double)Default_1000x_Temperature_Offset / 1000);
                
                if((Default_T_Zero != User_T_Zero) | (Default_ADC_Zero != User_ADC_Zero))
                {
//                    cx = ((double)User_ADC_Zero - (double)Default_ADC_Zero);
//                    cx = cx * 0.076295109483;
//                    Zero_compensation = (double)Default_100000x_m_Plus / 100000 * User_T_Zero_float;
//                    Zero_compensation = exp(Zero_compensation);
//                    Zero_compensation = Zero_compensation * (double)Default_1000x_A_Plus / 1000;
//                    Zero_compensation = Zero_compensation + (double)Default_1000x_B_Plus / 1000;
//                    Zero_compensation = cx - Zero_compensation;
//                    Zero_compensation = 1000 * Zero_compensation / (double)Default_pA_per_PPM_Plus;
//                    Span_compensation = Default_100x_C0_Plus / 100;
//                    Span_compensation = Span_compensation + ((double)Default_10000x_C1_Plus / 10000 * User_T_Zero_float);
//                    Span_compensation = Span_compensation + ((double)Default_1000000x_C2_Plus / 1000000 * User_T_Zero_float * User_T_Zero_float);
//                    Span_compensation = Span_compensation / 100;
//                    PPB_old = 1000 * Zero_compensation / Span_compensation;
                    
                    PPB_old = PPB_calculation(User_ADC_Zero, Default_ADC_Zero, User_T_Zero_float, Default_pA_per_PPM_Plus, 
                                                             Default_1000x_A_Plus, Default_1000x_B_Plus, Default_100000x_m_Plus, 
                                                             Default_100x_C0_Plus, Default_10000x_C1_Plus, Default_1000000x_C2_Plus);
                }
                else
                {
                    PPB_old = 0;
                }
                
//                cx = ((double)ADC - (double)Default_ADC_Zero);
//                cx = cx * 0.076295109483;
//                Zero_compensation = (double)Default_100000x_m_Plus / 100000 * T_float;
//                Zero_compensation = exp(Zero_compensation);
//                Zero_compensation = Zero_compensation * (double)Default_1000x_A_Plus / 1000;
//                Zero_compensation = Zero_compensation + (double)Default_1000x_B_Plus / 1000;
//                Zero_compensation = cx - Zero_compensation;
//                Zero_compensation = 1000 * Zero_compensation / (double)Default_pA_per_PPM_Plus;
//                Span_compensation = Default_100x_C0_Plus / 100;
//                Span_compensation = Span_compensation + ((double)Default_10000x_C1_Plus / 10000 * T_float);
//                Span_compensation = Span_compensation + ((double)Default_1000000x_C2_Plus / 1000000 * T_float * T_float);
//                Span_compensation = Span_compensation / 100;
//                PPB_CO = 1000 * Zero_compensation / Span_compensation - PPB_old;
                
                PPB_CO = PPB_calculation(ADC, Default_ADC_Zero, T_float, Default_pA_per_PPM_Plus, 
                                              Default_1000x_A_Plus, Default_1000x_B_Plus, Default_100000x_m_Plus, 
                                              Default_100x_C0_Plus, Default_10000x_C1_Plus, Default_1000000x_C2_Plus) - PPB_old;
                
                if((PPB_CO < 0) & (Operation_Mode == '3'))
                {
                    PPB_CO = 0;
                }
                else;

                ltoa(Buffer, (long int)PPB_CO, 10);
                delay(1000);
                UART2_xmits(", ");
                UART2_xmits(Buffer); 
            }
            else;
            
            while(1)
            {   
                RCFGCALbits.RTCPTR = 0;
                MINTEN = RTCVAL;
                MINTEN = (0b0000000000000111) & (MINTEN >> 12);
                RCFGCALbits.RTCPTR = 0;
                MINONE = RTCVAL;
                MINONE = (0b0000000000001111) & (MINONE >> 8);
                RCFGCALbits.RTCPTR = 0;
                SECTEN = RTCVAL;
                SECTEN = (0b0000000000000111) & (SECTEN >> 4);
                RCFGCALbits.RTCPTR = 0;
                SECONE = RTCVAL;
                SECONE = (0b0000000000001111) & (SECONE >> 0);
                
                if(Readout_delay == 0)    
                {
                    break;
                }
                else if(Readout_delay < 10)    
                {
                    if((SECONE == 0) | (SECONE == 5)) break;
                }
                else if(Readout_delay < 30)
                {
                    if(SECONE == 0) break;
                }
                else if(Readout_delay < 60)
                {
                    if((SECONE == 0) & ((SECTEN == 0) | (SECTEN == 3))) break;
                }
                else
                {
                    if((SECONE == 0) & (SECTEN == 0)) break;
                }                              
                ClrWdt();               
            }
            
            if((Operation_Mode == '1') | (Operation_Mode == '2') | (Operation_Mode == '3'))
            {
                itoa(Buffer, (int)T_float, 10);
                delay(1000);
                UART2_xmits(", ");
                UART2_xmits(Buffer);
            } 
            else
            {
                utoa(Buffer, T, 10);
                delay(1000);
                UART2_xmits(", ");
                UART2_xmits(Buffer);
            }
            
            RH = Si7021_Read_RH();
            RH_float = Si7021_Calculate_RH(RH);
            if(RH_float > 100)
            {
                RH_float = 100;
            }
            else if(RH_float < 0)
            {
                RH_float = 0;
            }
            else;

            if((Operation_Mode == '1') | (Operation_Mode == '2') | (Operation_Mode == '3'))
            {
                utoa(Buffer, (unsigned int)RH_float, 10);
                delay(1000);
                UART2_xmits(", ");
                UART2_xmits(Buffer);
            } 
            else
            {
                utoa(Buffer, RH, 10);
                delay(1000);
                UART2_xmits(", ");
                UART2_xmits(Buffer);
            }

            RCFGCALbits.RTCPTR = 3;
            YRTEN = RTCVAL;
            YRTEN = (0b0000000000001111) & (YRTEN >> 4);
            RCFGCALbits.RTCPTR = 3;
            YRONE = RTCVAL;
            YRONE = (0b0000000000001111) & (YRONE >> 0);
            RCFGCALbits.RTCPTR = 2;
            MTHTEN = RTCVAL;
            MTHTEN = (0b0000000000000001) & (MTHTEN >> 12);
            RCFGCALbits.RTCPTR = 2;
            MTHONE = RTCVAL;
            MTHONE = (0b0000000000001111) & (MTHONE >> 8);
            RCFGCALbits.RTCPTR = 2;
            DAYTEN = RTCVAL;
            DAYTEN = (0b0000000000000011) & (DAYTEN >> 4);
            RCFGCALbits.RTCPTR = 2;
            DAYONE = RTCVAL;
            DAYONE = (0b0000000000001111) & (DAYONE >> 0);
            RCFGCALbits.RTCPTR = 1;
            HRTEN = RTCVAL;
            HRTEN = (0b0000000000000011) & (HRTEN >> 4);
            RCFGCALbits.RTCPTR = 1;
            HRONE = RTCVAL;
            HRONE = (0b0000000000001111) & (HRONE >> 0);
            RCFGCALbits.RTCPTR = 0;
            MINTEN = RTCVAL;
            MINTEN = (0b0000000000000111) & (MINTEN >> 12);
            RCFGCALbits.RTCPTR = 0;
            MINONE = RTCVAL;
            MINONE = (0b0000000000001111) & (MINONE >> 8);
            RCFGCALbits.RTCPTR = 0;
            SECTEN = RTCVAL;
            SECTEN = (0b0000000000000111) & (SECTEN >> 4);
            RCFGCALbits.RTCPTR = 0;
            SECONE = RTCVAL;
            SECONE = (0b0000000000001111) & (SECONE >> 0);

            if(Operation_Mode == '0')
            {
                UART2_xmits(", ");
                utoa(Buffer, YRTEN, 10);
                delay(1000);
                UART2_xmitc(Buffer[0]);
                utoa(Buffer, YRONE, 10);
                delay(1000);
                UART2_xmits(Buffer);
                UART2_xmits(", ");
                utoa(Buffer, MTHTEN, 10);
                delay(1000);
                UART2_xmitc(Buffer[0]);
                utoa(Buffer, MTHONE, 10);
                delay(1000);
                UART2_xmits(Buffer);
                UART2_xmits(", ");
                utoa(Buffer, DAYTEN, 10);
                delay(1000);
                UART2_xmitc(Buffer[0]);
                utoa(Buffer, DAYONE, 10);
                delay(1000);
                UART2_xmits(Buffer);
                UART2_xmits(", ");
                utoa(Buffer, HRTEN, 10);
                delay(1000);
                UART2_xmitc(Buffer[0]);
                utoa(Buffer, HRONE, 10);
                delay(1000);
                UART2_xmits(Buffer);
                UART2_xmits(", ");
                utoa(Buffer, MINTEN, 10);
                delay(1000);
                UART2_xmitc(Buffer[0]);
                utoa(Buffer, MINONE, 10);
                delay(1000);
                UART2_xmits(Buffer);
                UART2_xmits(", ");
                utoa(Buffer, SECTEN, 10);
                delay(1000);
                UART2_xmitc(Buffer[0]);
                utoa(Buffer, SECONE, 10);
                delay(1000);
                UART2_xmits_NewLine(Buffer);
            }
            else
            {
               UART2_xmits("\r\n"); 
            }
            
            if(Readout_delay > 10)
            {
                delay(4000000);
            }
            else;

            if(IFS1bits.U2RXIF)
            {
                IFS1bits.U2RXIF = 0;
                user_input = U2RXREG;
                if(user_input == 'r')
                {
                    while(1);
                }
                else if(user_input == 'R')
                {
                    while(1);
                }
                else;
            }
            
            ClrWdt();
        }while(counter > 0);
    
    counter++;    
    
    user_input = U2RXREG;
/**********************************************************************Help Menu**********************************************************************/
//    if(user_input == 'h')
//    {
//        UART2_xmits("Enter z to set zero \r\n");
//        UART2_xmits("Enter c to read CO \r\n");
//        UART2_xmits("Enter e to read EEPROM \r\n");
//        UART2_xmits("Enter d to reset defaults \r\n");
    
//    while(1);
//    }
/***************************************************************Set User Span***********************************************************************/    
//    else if(user_input == 's')
//    {
//        User_ADC_Span = ADC_Read(16);
//
//        writeNVM (140,User_ADC_Span);
//        delay(100);
    
//    while(1);
//    }
/**************************************************************Set Factory Span***********************************************************************/     
//    else if(user_input == 'S')
//    {
//        Unlock(Security_Code);
//
//        UART2_xmits("Enter default span gas value in PPM: ");
//
//        UART_Entry();
//
//        Default_10x_PPB_Span = (unsigned int)(100 * atof(Buffer));
//        Default_10x_PPB_Span = Default_10x_PPB_Span & 0xFFFF;
//
//        writeNVM (46,Default_10x_PPB_Span);
//        delay(100);
//
//        UART2_xmits_NewLine("Setting default span ");
//
//        Default_ADC_Span = ADC_Read(16);
//
//        writeNVM (40,Default_ADC_Span);
//        delay(100);
//        
//        User_ADC_Span = Default_ADC_Span;
//
//        writeNVM (140,User_ADC_Span);
//        delay(100);
    
//    while(1);
//    }
/***************************************************************Set User Zero***********************************************************************/
    if(user_input == 'z')
    {
        UART2_xmits_NewLine("Setting user zero ");
        
        T = Si7021_Read_T();
        T_float = Si7021_Calculate_T(T);
        if(T_float > 35)
        {
            UART2_xmits_NewLine("Error, zero not saved ");
            while(1); 
        }
        else if(T_float < 5)
        {
            UART2_xmits_NewLine("Error, zero not saved ");
            while(1); 
        }
        else;

        ADC = ADC_Read(16);
        
        if(ADC > (Default_ADC_Zero + 655))
        {
            UART2_xmits_NewLine("Error, zero not saved ");
            while(1);
        }
        else if(ADC < (Default_ADC_Zero - 655))
        {
            UART2_xmits_NewLine("Error, zero not saved ");
            while(1);
        }
        else
        {
            User_ADC_Zero = ADC;
            
            writeNVM(130,User_ADC_Zero);

            User_T_Zero = Si7021_Read_T();

            writeNVM(132,User_T_Zero);

            User_RH_Zero = Si7021_Read_RH();

            writeNVM(134,User_RH_Zero);
        }
    }
/**************************************************************Set Factory Zero***********************************************************************/    
    else if(user_input == 'Z')
    {
        Unlock(Security_Code);

        UART2_xmits_NewLine("\r\nSetting default zero ");

        Default_ADC_Zero = ADC_Read(16);

        writeNVM(30,Default_ADC_Zero);

        Default_T_Zero = Si7021_Read_T();

        writeNVM(32,Default_T_Zero);

        Default_RH_Zero = Si7021_Read_RH();

        writeNVM(34,Default_RH_Zero);
        
        User_ADC_Zero = Default_ADC_Zero;

        writeNVM(130,User_ADC_Zero);

        User_T_Zero = Default_T_Zero;

        writeNVM(132,User_T_Zero);

        User_RH_Zero = Default_RH_Zero;

        writeNVM(134,User_RH_Zero);
    }
/******************************************************************Restore Defaults************************************************************************/
    else if(user_input == 'd')
    {
        UART2_xmits_NewLine("Restoring defaults ");

        User_ADC_Zero = Default_ADC_Zero;
        writeNVM(130,User_ADC_Zero);

        User_T_Zero = Default_T_Zero;
        writeNVM(132,User_T_Zero);

        User_RH_Zero = Default_RH_Zero;
        writeNVM(134,User_RH_Zero);

        User_ADC_Span = Default_ADC_Span;
        writeNVM(140,User_ADC_Span);
    }   
/*****************************************************************Set Factory Defaults**********************************************************************/    
    else if(user_input == 'D')
    {
        Unlock(Security_Code);
        
        UART2_xmits("\r\nOperation_Mode: ");
        UART_Entry();
        Operation_Mode = Buffer[0];
        writeNVM(80,Operation_Mode);    
                              
        UART2_xmits("\r\nEnter Temperature_Offset: ");
        UART_Entry();
        Default_1000x_Temperature_Offset = (int)(1000 * atof(Buffer));
        Default_1000x_Temperature_Offset = Default_1000x_Temperature_Offset & 0xFFFF;
        writeNVM(20,Default_1000x_Temperature_Offset);        

        UART2_xmits("\r\nEnter nA_per_PPM_Basic: ");
        UART_Entry();
        Default_pA_per_PPM_Basic = (unsigned int)(1000 * atof(Buffer));
        Default_pA_per_PPM_Basic = Default_pA_per_PPM_Basic & 0xFFFF;
        writeNVM(70,Default_pA_per_PPM_Basic);
        
        UART2_xmits("\r\nEnter nA_per_PPM_Standard: ");
        UART_Entry();
        Default_pA_per_PPM_Standard = (unsigned int)(1000 * atof(Buffer));
        Default_pA_per_PPM_Standard = Default_pA_per_PPM_Standard & 0xFFFF;
        writeNVM(72,Default_pA_per_PPM_Standard);
        
        UART2_xmits("\r\nEnter nA_per_PPM_Plus: ");
        UART_Entry();
        Default_pA_per_PPM_Plus = (unsigned int)(1000 * atof(Buffer));
        Default_pA_per_PPM_Plus = Default_pA_per_PPM_Plus & 0xFFFF;
        writeNVM(74,Default_pA_per_PPM_Plus);
        
        UART2_xmits("\r\nEnter LMP91000 Register 0x11: ");
        UART_Entry();
        LMP91000_B11 = (unsigned int)atoi(Buffer);
        LMP91000_B11 = LMP91000_B11 & 0xFFFF;
        writeNVM(54,LMP91000_B11);
        
        UART2_xmits("\r\nEnter Board_Name: ");
        UART_Entry();
        j = 100;
        i = 0;
        while(i < 12)
        {
            Board_Name_[i] = Buffer[i];
            writeNVM (j,Board_Name_[i]);
            delay(100);
            j = j + 2;
            i++;
        } 
        
        UART2_xmits("\r\nEnter A_Plus: ");
        UART_Entry();
        Default_1000x_A_Plus = (int)(1000 * atof(Buffer));
        Default_1000x_A_Plus = Default_1000x_A_Plus & 0xFFFF;
        writeNVM(202,Default_1000x_A_Plus);
        
        UART2_xmits("\r\nEnter B_Plus: ");
        UART_Entry();
        Default_1000x_B_Plus = (int)(1000 * atof(Buffer));
        Default_1000x_B_Plus = Default_1000x_B_Plus & 0xFFFF;
        writeNVM(204,Default_1000x_B_Plus);
        
        UART2_xmits("\r\nEnter m_Plus: ");
        UART_Entry();
        Default_100000x_m_Plus = (int)(100000 * atof(Buffer));
        Default_100000x_m_Plus = Default_100000x_m_Plus & 0xFFFF;
        writeNVM(206,Default_100000x_m_Plus);
        
        UART2_xmits_NewLine("\r\nRemove sensor and press any key ");
        while(!IFS1bits.U2RXIF)
        {
            ClrWdt();
        }
        IFS1bits.U2RXIF = 0;

        Default_ADC_OC = ADC_Read(16);

        writeNVM(12,Default_ADC_OC);
    }    
/****************************************************************EEPROM Readout********************************************************************/    
    else if(user_input == 'e')
    {       
        UART2_xmits_NewLine("                          User EEPROM Values");
        
//        Operation_Mode = readNVM(80);
        UART2_xmits("Operation_Mode = ");
        UART2_xmitc(Operation_Mode);
        
//        User_ADC_Zero = readNVM(130);
        utoa(Buffer, User_ADC_Zero, 10);
        delay(1000);
        UART2_xmits("\r\nUser_ADC_Zero = ");
        UART2_xmits_NewLine(Buffer);

//        User_T_Zero = readNVM(132);
        utoa(Buffer, User_T_Zero, 10);
        delay(1000);
        UART2_xmits("User_T_Zero = ");
        UART2_xmits_NewLine(Buffer);

//        User_RH_Zero = readNVM(134);
        utoa(Buffer, User_RH_Zero, 10);
        delay(1000);
        UART2_xmits("User_RH_Zero = ");
        UART2_xmits_NewLine(Buffer);
    }  
    else if(user_input == 'E')
    {
        Unlock(Security_Code);

        UART2_xmits_NewLine("\r\n                         Default EEPROM Values");

//        Default_ADC_Zero = readNVM(30);
        utoa(Buffer, Default_ADC_Zero, 10);
        delay(1000);
        UART2_xmits("Default_ADC_Zero = ");
        UART2_xmits_NewLine(Buffer);
        
//        Default_ADC_OC = readNVM(12);
        utoa(Buffer, Default_ADC_OC, 10);
        delay(1000);
        UART2_xmits("Default_ADC_OC = ");
        UART2_xmits_NewLine(Buffer);
                
//        Default_1000x_Temperature_Offset = readNVM(20);
        itoa(Buffer, Default_1000x_Temperature_Offset, 10);
        delay(1000);
        UART2_xmits("Default_1000x_Temperature_Offset = ");
        UART2_xmits_NewLine(Buffer);        

//        Default_T_Zero = readNVM(32);
        utoa(Buffer, Default_T_Zero, 10);
        delay(1000);
        UART2_xmits("Default_T_Zero = ");
        UART2_xmits_NewLine(Buffer);

//        Default_RH_Zero = readNVM(34);
        utoa(Buffer, Default_RH_Zero, 10);
        delay(1000);
        UART2_xmits("Default_RH_Zero = ");
        UART2_xmits_NewLine(Buffer);

//        Default_pA_per_PPM_Basic = readNVM(70);
        utoa(Buffer, Default_pA_per_PPM_Basic, 10);
        delay(1000);
        UART2_xmits("Default_pA_per_PPM_Basic = ");
        UART2_xmits_NewLine(Buffer);
        
//        Default_pA_per_PPM_Standard = readNVM(72);
        utoa(Buffer, Default_pA_per_PPM_Standard, 10);
        delay(1000);
        UART2_xmits("Default_pA_per_PPM_Standard = ");
        UART2_xmits_NewLine(Buffer);
        
//        Default_pA_per_PPM_Plus = readNVM(74);
        utoa(Buffer, Default_pA_per_PPM_Plus, 10);
        delay(1000);
        UART2_xmits("Default_pA_per_PPM_Plus = ");
        UART2_xmits_NewLine(Buffer);
        
//        Default_pA_per_PPM_Plus = readNVM(54);
        utoa(Buffer, LMP91000_B11, 10);
        delay(1000);
        UART2_xmits("LMP91000 Register 0x11 = ");
        UART2_xmits_NewLine(Buffer);

//        Default_1000x_A_Plus = readNVM(202);
//        itoa(Buffer, Default_1000x_A_Plus, 10);
//        delay(1000);
//        UART2_xmits("Default_1000x_A_Plus = ");
//        UART2_xmits_NewLine(Buffer);
        
//        Default_1000x_B_Plus = readNVM(204);
//        itoa(Buffer, Default_1000x_B_Plus, 10);
//        delay(1000);
//        UART2_xmits("Default_1000x_B_Plus = ");
//        UART2_xmits_NewLine(Buffer);
        
//        Default_100000x_m_Plus = readNVM(206);
//        itoa(Buffer, Default_100000x_m_Plus, 10);
//        delay(1000);
//        UART2_xmits("Default_100000x_m_Plus = ");
//        UART2_xmits_NewLine(Buffer);
    }
    else;
    
    if(user_input != 'c')
    {
        U2MODEbits.UARTEN = 0;
        U2MODEbits.USIDL = 0;
        U2MODEbits.WAKE = 1;

        //  U1BRG = (Fcy/(32*BaudRate)) - 1  or  U1BRG = (Fcy/(8*BaudRate)) - 1
        U2BRG = 25;	// 7.37Mhz osc, 9600 Baud BRGH = 0 

        IEC1bits.U2RXIE = 1;

        U2MODEbits.UARTEN = 1;	// And turn the peripheral on
        U2STAbits.UTXEN = 1;

        RCONbits.WDTO = 0;
        RCONbits.SWDTEN = 0;
        delay(1000);
        Sleep();
        while(1);
    }
    else;
    }
    while(1);
    return 0;
}
