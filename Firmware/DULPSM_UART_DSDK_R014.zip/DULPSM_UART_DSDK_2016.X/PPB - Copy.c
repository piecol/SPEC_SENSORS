#include <xc.h>
#include <math.h>

double PPB_calculation(unsigned int User_ADC_Zero, unsigned int Default_ADC_Zero, double T_float, unsigned int Default_pA_per_PPM, 
                       double Default_1000x_A, double Default_1000x_B, double Default_100000x_m, 
                       double Default_100x_C0, double Default_10000x_C1, double Default_1000000x_C2)
{
    double cx;
    double Zero_compensation;
    double Span_compensation;
    double PPB;
    
    cx = ((double)User_ADC_Zero - (double)Default_ADC_Zero);
    cx = cx * 0.076295109483;
    Zero_compensation = (double)Default_100000x_m / 100000 * T_float;
    Zero_compensation = exp(Zero_compensation);
    Zero_compensation = Zero_compensation * (double)Default_1000x_A / 1000;
    Zero_compensation = Zero_compensation + (double)Default_1000x_B / 1000;
    Zero_compensation = cx - Zero_compensation;
    Zero_compensation = 1000 * Zero_compensation / (double)Default_pA_per_PPM;
    Span_compensation = (double)Default_100x_C0 / 100;
    Span_compensation = Span_compensation + ((double)Default_10000x_C1 / 10000 * T_float);
    Span_compensation = Span_compensation + ((double)Default_1000000x_C2 / 1000000 * T_float * T_float);
    Span_compensation = Span_compensation / 100;
    PPB = 1000 * Zero_compensation / Span_compensation;
    
    return PPB;
}

double PPB_Calculation(unsigned int ADC, unsigned int ADC_Zero, int nA_per_PPM_x100, double T_float, unsigned long int Part_Number)
{
    double Tkz = 25;
    double Tks = 25;  
    double nA;
    double Cx;
    unsigned long int Rgain = 500000;
    double Zc;
    double Zcf;
    double Zcf_low;
    double Zcf_high;   
    double Sc;
    double Scf;
    double Scf_low;
    double Scf_high;    
       
    if(Part_Number == 110102)
    {
        Zcf_low = 0;
        Zcf_high = 2.375;
        Scf_low = 0.6;
        Scf_high = 0.4;
    }
    else if(Part_Number == 110202)
    {
        Zcf_low = 1.7;
        Zcf_high = 22.5;
        Scf_low = 1.2;
        Scf_high = 0;
    }
    else if(Part_Number == 110303)
    {
        Zcf_low = 0;
        Zcf_high = 0;
        Scf_low = 0.3;
        Scf_high = 0;
    }
    else if(Part_Number == 110601)
    {
        Zcf_low = 0;
        Zcf_high = 15;
        Scf_low = 1.2;
        Scf_high = 0.5;
    }
    else if(Part_Number == 110501)
    {
        Zcf_low = 0;
        Zcf_high = -1.6;
        Scf_low = 0;
        Scf_high = 0.4;
    }
    else if(Part_Number == 110401)
    {
        Zcf_low = 0;
        Zcf_high = 0;
        Scf_low = 0;
        Scf_high = 0.5;
    }
    else if(Part_Number == 110801)
    {
        Zcf_low = 0;
        Zcf_high = 0;
        Scf_low = 0;
        Scf_high = 0;
    }
    else if(Part_Number == 110901)
    {
        Zcf_low = 0;
        Zcf_high = 0;
        Scf_low = 0;
        Scf_high = 0;
    }
    else if(Part_Number == 999036)
    {
        Zcf_low = 0;
        Zcf_high = 0;
        Scf_low = 0;
        Scf_high = 0;
    }
    else;
    
    if(T_float < Tkz)
    {
        Zcf = Zcf_low;
    }
    else
    {
        Zcf = Zcf_high;
    }
    
    if(T_float < Tks)
    {
        Scf = Scf_low;
    }
    else
    {
        Scf = Scf_high; 
    }
       
    nA = ((double)ADC - (double)ADC_Zero) / 65535 * 2.048 / (double)Rgain * 1E9;
//    Cx = nA / nA_per_PPM_x100 * 1000;
    Zc = nA - (Zcf * (T_float - Tkz));
    Sc = 1 - (Scf / 100 * (T_float - Tks));
    Cx = Zc * Sc / (double)nA_per_PPM_x100 * 1E5;

    return Cx;
}
